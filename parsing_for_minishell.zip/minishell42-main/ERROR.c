/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ERROR.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psmolich <psmolich@student.42berlin.de>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/13 15:17:08 by psmolich          #+#    #+#             */
/*   Updated: 2026/02/16 11:38:09 by psmolich         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	error_msg(char *message)
{
	ft_putstr_fd(message, 2);
}

void	error_exit(char *message, int exit_code)
{
	error_msg(message);
	exit(exit_code);
}
